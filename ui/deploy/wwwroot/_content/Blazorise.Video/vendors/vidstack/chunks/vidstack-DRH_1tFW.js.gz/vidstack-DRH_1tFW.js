const o=Symbol(0),t=Symbol(0),l={setAuto:o,enableAuto:t};export{l as Q};
