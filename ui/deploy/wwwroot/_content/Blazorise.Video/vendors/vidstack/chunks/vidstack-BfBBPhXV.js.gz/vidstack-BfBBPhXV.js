function t(s){return s instanceof Error?s:Error(typeof s=="string"?s:JSON.stringify(s))}function n(s,i){if(!s)throw Error("Assertion failed.")}export{n as a,t as c};
