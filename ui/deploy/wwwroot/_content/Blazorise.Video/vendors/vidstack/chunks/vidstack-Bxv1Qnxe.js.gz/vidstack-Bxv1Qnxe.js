function e(t,n=2){return Number(t.toFixed(n))}function u(t){return String(t).split(".")[1]?.length??0}function a(t,n,r){return Math.max(t,Math.min(r,n))}export{a as c,u as g,e as r};
